function calculate(operator) {
    const num1 = parseFloat(document.getElementById("num1").value);
    const num2 = parseFloat(document.getElementById("num2").value);
    const resultDiv = document.getElementById("result");
    const imageContainer = document.getElementById("image-container");
    const resultImg = document.getElementById("result-img");
  
    resultImg.style.display = "none";
  
    if (isNaN(num1) || isNaN(num2)) {
      resultDiv.textContent = "Por favor, ingresa dos números válidos.";
      resultImg.src = "https://img.freepik.com/premium-vector/error-404-sign-pixel-art-style_475147-2515.jpg?size=626&ext=jpg";
      resultImg.style.display = "block";
      return;
    }
  
    let result;
  
    switch (operator) {
      case "+":
        result = num1 + num2;
        break;
      case "-":
        result = num1 - num2;
        break;
      case "*":
        result = num1 * num2;
        break;
      case "/":
        if (num2 === 0) {
          resultDiv.textContent = "❌ Error: No se puede dividir entre cero.";
          resultImg.src = "https://img.freepik.com/premium-vector/error-404-sign-pixel-art-style_475147-2515.jpg?size=626&ext=jpg";
          resultImg.style.display = "block";
          return;
        }
        result = num1 / num2;
        break;
      default:
        resultDiv.textContent = "Operación no válida.";
        return;
    }
  
    resultDiv.textContent = `Resultado: ${result}`;
    resultImg.src = "https://sdmntprsouthcentralus.oaiusercontent.com/files/00000000-a5f8-61f7-91ff-e6a1659c1862/raw?se=2025-04-13T03%3A25%3A01Z&sp=r&sv=2024-08-04&sr=b&scid=e143149a-4ae9-52be-9af1-85e4b8fde020&skoid=f0c3f613-0f9b-4a8a-a29a-c1a910343ad7&sktid=a48cca56-e6da-484e-a814-9c849652bcb3&skt=2025-04-12T19%3A13%3A54Z&ske=2025-04-13T19%3A13%3A54Z&sks=b&skv=2024-08-04&sig=iwIJJPc5C2mWGjJD95lSmHBZMWJGg6JkwycsLNM3UYk%3D"; // Imagen de éxito
    resultImg.style.display = "block";
  }
  